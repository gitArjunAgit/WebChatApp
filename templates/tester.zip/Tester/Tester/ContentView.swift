import SwiftUI
import AppKit
public import Combine

struct CosmicButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 20, weight: .bold, design: .rounded))
            .foregroundColor(.white)
            .padding(.horizontal, 40)
            .padding(.vertical, 16)
            .background(
                LinearGradient(colors: [.purple, .indigo, .black],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
            )
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.cyan.opacity(0.8), lineWidth: configuration.isPressed ? 4 : 2)
            )
            .shadow(color: .purple.opacity(configuration.isPressed ? 0.4 : 0.8),
                    radius: configuration.isPressed ? 4 : 15,
                    x: 0,
                    y: configuration.isPressed ? 2 : 10)
            .scaleEffect(configuration.isPressed ? 0.92 : 1.0)
            .animation(.spring(response: 0.2, dampingFraction: 0.5), value: configuration.isPressed)
    }
}

struct Planet: Identifiable {
    let id = UUID()
    var position: CGPoint
    var color: Color
    var size: CGFloat
    var isExploded: Bool = false
}

// Stars now use relative positioning to handle window resizing
struct Star: Identifiable {
    let id = UUID()
    let relativeX: CGFloat
    let relativeY: CGFloat
    let size: CGFloat
    let opacity: Double
}

struct ContentView: View {
    @State private var planets: [Planet] = []
    @State private var stars: [Star] = []
    let timer = Timer.publish(every: 1.2, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Deep Space Gradient Background
                LinearGradient(
                    colors: [Color(red: 0.1, green: 0.0, blue: 0.2),
                             .black,
                             Color(red: 0.0, green: 0.1, blue: 0.2)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                // Scalable Starscape
                ForEach(stars) { star in
                    Circle()
                        .fill(Color.white.opacity(star.opacity))
                        .frame(width: star.size, height: star.size)
                        // Multiply relative position by current screen size
                        .position(x: star.relativeX * geometry.size.width,
                                  y: star.relativeY * geometry.size.height)
                }

                // Spawning Planets
                ForEach($planets) { $planet in
                    Circle()
                        .fill(
                            RadialGradient(gradient: Gradient(colors: [planet.color, .black]),
                                           center: .center,
                                           startRadius: 0,
                                           endRadius: planet.size / 1.2)
                        )
                        .frame(width: planet.size, height: planet.size)
                        .position(planet.position)
                        .scaleEffect(planet.isExploded ? 3.0 : 1.0)
                        .opacity(planet.isExploded ? 0.0 : 1.0)
                        .onTapGesture {
                            NSSound(named: "Hero")?.play()
                            withAnimation(.easeOut(duration: 0.4)) {
                                planet.isExploded = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                planets.removeAll { $0.id == planet.id }
                            }
                        }
                }

                // Main Button
                VStack {
                    Button(action: {
                        NSSound(named: "Glass")?.play()
                    }) {
                        Text("Ignite Thrusters")
                    }
                    .buttonStyle(CosmicButtonStyle())
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .onAppear {
                generateStars()
            }
            .onReceive(timer) { _ in
                spawnPlanet(in: geometry.size)
            }
        }
        .frame(minWidth: 800, minHeight: 600)
    }

    func generateStars() {
        stars = (0..<200).map { _ in
            Star(
                // Store percentage values (0.0 to 1.0) instead of exact pixels
                relativeX: CGFloat.random(in: 0...1),
                relativeY: CGFloat.random(in: 0...1),
                size: CGFloat.random(in: 1...3),
                opacity: Double.random(in: 0.2...1.0)
            )
        }
    }

    func spawnPlanet(in size: CGSize) {
        let colors: [Color] = [.orange, .cyan, .pink, .purple, .green, .mint]
        let newPlanet = Planet(
            position: CGPoint(x: CGFloat.random(in: 50...(size.width - 50)),
                              y: CGFloat.random(in: 50...(size.height - 50))),
            color: colors.randomElement() ?? .white,
            size: CGFloat.random(in: 40...100)
        )
        planets.append(newPlanet)
        
        if planets.count > 15 {
            planets.removeFirst()
        }
    }
}

@main
struct CosmicButtonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

#Preview {
    ContentView()
}
